"""
Passenger WSGI entry point for SiteGround deployment.
"""
import os
import sys

# Add the application directory to Python path
sys.path.insert(0, os.path.dirname(__file__))

# Import the Flask application
from wsgi import app as application
