"""
SiteGround setup helper for Bexo Cargo application.
Run this file once after uploading to SiteGround to initialize the database.
"""
import os
import sys

try:
    from app import db
    print("Initializing database tables...")
    db.create_all()
    print("Database initialization successful!")
    
    print("\nSetting up admin user...")
    from models import Admin
    from werkzeug.security import generate_password_hash
    
    # Check if admin already exists
    from app import db
    admin = Admin.query.filter_by(username='admin').first()
    
    if admin:
        print("Admin user already exists.")
    else:
        # Create admin user with default credentials (change these immediately after setup)
        admin = Admin(
            username='admin',
            password_hash=generate_password_hash('admin123')
        )
        db.session.add(admin)
        db.session.commit()
        print("Default admin user created with username 'admin' and password 'admin123'")
        print("IMPORTANT: Login and change this password immediately!")
    
    print("\nBexo Cargo setup complete!")
    
except Exception as e:
    print(f"Error during setup: {e}")
    sys.exit(1)
